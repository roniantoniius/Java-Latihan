package com.roniantonius.colours;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ColoursApplicationTests {

	@Test
	void contextLoads() {
	}

}
